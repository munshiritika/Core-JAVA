package day1;
//12-21-2023, Thursday
import java.util.Scanner;

public class Fibonacci_Series {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = input.nextInt();
		
		System.out.println("Fibonacci Series for " + num + ":");
		int num1 = 0, num2 = 1, num3 = 0;
		
	    for (int i = 1; i <= num; ++i) {
	      System.out.print(num1 + " ");

	      num3 = num1 + num2;
	      num1 = num2;
	      num2 = num3;
	    }

	}
}
