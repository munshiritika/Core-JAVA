package day1;
//12-22-2023, Friday
import java.util.Scanner;
public class ShapeAndAreas {
	//Create a class Shape in which create 5 methods to find area of 5 different shapes and call It outside the class.
	
	//Area of the Triangle
	public static void traingle() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the height of the traingle:");
		int height = input.nextInt();
		
		System.out.print("Enter the base of the traingle: ");
		int base = input.nextInt();

		double area_triangle = (base * height)/2;
		System.out.println("Area of the Triangle: " + area_triangle);
	}
	
	//Area of the Parallelogram
	public static void parallelogram() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the height of the parallelogram:");
		int height = input.nextInt();
		
		System.out.print("Enter the base of the parallelogram: ");
		int base = input.nextInt();

		double area_parallelogram = base * height;
		System.out.println("Area of the Parallelogram: " + area_parallelogram);
	}
	
	//Area of the Rhombus
	public static void rhombus() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the height of the rhombus:");
		int height = input.nextInt();
		
		System.out.print("Enter the base of the rhombus: ");
		int base = input.nextInt();

		double area_rhombus = base * height;
		System.out.println("Area of the Rhombus: " + area_rhombus);
	}

	//Area of the Square
	public static void square() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the side of the square:");
		int side = input.nextInt();

		double area_square = side * side;
		System.out.println("Area of the Square: " + area_square);
	}
	
	//Area of the Rectangle
	public static void rectangle() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the length of the rectangle:");
		int length = input.nextInt();
		
		System.out.print("Enter the width of the rectangle: ");
		int width = input.nextInt();

		double area_rectangle = length * width;
		System.out.println("Area of the Rectangle: " + area_rectangle);
	}
	
}
