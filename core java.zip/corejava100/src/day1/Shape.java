package day1;
//12-19-2023, Tuesday
public class Shape {

	public static void main(String[] args) {
		//Area of Circle: pi*r*r
		float r = 7.2f;
		double area_circle = 3.14 * r * r;
		System.out.println("Area of Circle: " + area_circle);

		//Area of Cylinder: 2*pi*r*h + 2*pi*r*r
		int h = 10;
		double area_cylinder = (2 * 3.14 * r * h) + (2 * 3.14 * r * r);
		System.out.println("Area of Cylinder: " + area_cylinder);

		//Volume of Cube: a*a*a
		int a = 5;
		int volume_cube = a * a * a;
		System.out.println("Volume of Cube: " + volume_cube);
		
		//Volume of Cuboid: l*b*h
		int l = 10;
		int b = 20;
		int volume_cuboid = l * b * h;
		System.out.println("Volume of Cuboid: " + volume_cuboid);
	}

}
