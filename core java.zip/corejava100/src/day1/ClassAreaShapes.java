package day1;
//12-22-2023, Friday
import java.util.Scanner;
public class ClassAreaShapes {
	public static void rectangle() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Length=:");

		int l = sc.nextInt();

		System.out.println("Breadth=:");

		int b = sc.nextInt();

		int area = l * b;

		System.out.println("The area of the rectangle is=:" + area);

	}

	public static void Sqaure() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Side=:");

		int side = sc.nextInt();

		int area = side * side;

		System.out.println("The area of the Sqaure is=:" + area);

	}

	public static void fact() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Num=:");

		int num = sc.nextInt();

		int fact = 1;

		for (int i = 1; i <= num; i++) {

			fact = fact * i;

		}
		System.out.println("The factorail of the number is=:" + fact);

	}

	public static void main(String[] args) {
		fact();
		Sqaure();
		rectangle();
	}
}

