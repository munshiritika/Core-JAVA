package day1;
//12-20-2023, Wednesday
import java.util.Scanner;

public class OddAndEven {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("Enter the Number: ");
		int num = input.nextInt();
		
		System.out.print("Your Output is: ");

		if (num % 2 == 0) {
			System.out.println(num + " is a Even Number!!");
		} else {
			System.out.println(num + " is a Odd Number!!");
		}
	}
}
