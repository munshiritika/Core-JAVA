package day1;
//12-19-2023, Tuesday
public class Operation {

	public static void main(String[] args) {
		//addition
		int a = 10;
		int b = 5;

		int sum = a + b;
		System.out.println("Addition: " + sum);
		
		//subtraction
		int sub = a - b;
		System.out.println("Subtraction: " + sub);
		
		
		//multiplication
		int mul = a * b;		
		System.out.println("Multiplication: " + mul);
		
		
		//division		
		int div = a / b;
		System.out.println("Division: " + div);
	}

}
