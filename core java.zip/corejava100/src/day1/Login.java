package day1;
//12-20-2023, Wednesday
import java.util.Scanner;

public class Login {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the Username:");
		String username = input.next();
		
		System.out.print("Enter the Pin:");
		int pin = input.nextInt();
		
		System.out.print("Your Output is: ");

		if (username.equals("ritika") && pin == 1111) {
			System.out.println("Welcome to Home page " + username);
		}
		else if (username.equals("rohit") && pin == 2222) {
			System.out.println("Welcome to Home page " + username);
		}
		else if (username.equals("erica") && pin == 3456) {
			System.out.println("Welcome to Home page " + username);
		}
		else if (username.equals("michael") && pin == 9898) {
			System.out.println("Welcome to Home page " + username);
		}
		else {
			System.err.println("Sorry!! It is an Invalid Input..");
		}
	}

}