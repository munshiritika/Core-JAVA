package day1;
//12-20-2023, Wednesday
import java.util.Scanner;

public class PosOrNegNum {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the number: ");
		int num = input.nextInt();
		
		System.out.print("Your Output is: ");

		if (num > 0) {
			System.out.println(num + " is a Positive Number!!");
		}
		else if (num < 0) {
			System.out.println(num + " is a Negative Number!!");
		} else {
			System.out.println("Zero!!");
		}

	}

}
