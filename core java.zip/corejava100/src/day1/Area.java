package day1;

import java.util.Scanner;

//12-19-2023, Tuesday
public class Area {

	public static void main(String[] args) {
		//Area of Rectangle
		int l = 10;
		int b = 10;
		int area_rec = l * b;
		//System.out.println("Area of Rectangle: " + area_rec);
		
		//Area of Square
		int a = 5;
		int area_square = a * a;
	//	System.out.println("Area of Square: "+ area_square);
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter name: ");
		String name = input.nextLine();
		System.out.println(name);
		System.out.print("How are you: ");
		String ask = input.nextLine();
		System.out.println(ask);
		System.out.print("Describe yourself");
		String des = input.nextLine();
		System.out.println(des);
	}

}
