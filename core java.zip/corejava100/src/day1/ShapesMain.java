package day1;
//12-22-2023, Friday
public class ShapesMain {

	public static void main(String[] args) {
		//Calling circle and cylinder methods we created in Shapes class
		Shapes.circle();
		Shapes.cylinder();
	}

}
