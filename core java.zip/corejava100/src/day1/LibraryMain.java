package day1;
//12-27-2023, Wednesday
import week2.Library;

public class LibraryMain {

	public static void main(String[] args) {
		//Calling methods from Library class in week2 package
		String[] books_arr = {"Harry Potter", "To the Lighthouse",  "Pride and Prejudice", "Hamlet", "Helen Keller"};
		int[] loans = {1, 3, 8, 10, 9, 5};
		int[] year = {2010, 2012,2014, 2016,2018};
		
		Library.name();
		Library.books(books_arr, year);
		Library.loan(loans);
	}
}
