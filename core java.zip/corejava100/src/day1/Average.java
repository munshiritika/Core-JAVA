package day1;
//12-22-2023, Friday
import java.util.Arrays;
import java.util.Scanner;
public class Average {
	
	//Find out average of 10 numbers
	public static void averages() {
		double average = 0;
		double sum = 0;
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		int[] array = new int[n];
		
		//User inputing n numbers
		for(int i = 0; i < n; i++) {
			System.out.print("Enter number " + (i+1) + ": ");
			int num = input.nextInt();
			array[i] = num;			
		}
		
		//Sum of 10 numbers
		for(int i = 0; i < n; i++) {
			sum = sum + array[i];
		}
		
		//Find the average of n numbers
		average = sum/n;
		
		System.out.println("Numbers in an array: " + Arrays.toString(array));
		System.out.println("Sum of " + n + " numbers: " + sum);
		System.out.println("Average of " + n + " numbers: " + average);
	}
	
	//Calling the averages method
	public static void main(String[] args) {
		averages();
	}
}
