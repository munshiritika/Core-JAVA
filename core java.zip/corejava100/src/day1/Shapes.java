package day1;
//12-22-2023, Friday
import java.util.Scanner;
public class Shapes {

	public static void circle() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the radius of the circle: ");
		int radius = input.nextInt();
		
		double area_circle = 3.14 * radius * radius;
		System.out.println("Area of the Circle: " + area_circle);
		System.out.println("\n");
	}
	
	public static void cylinder() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the height of the cylinder:");
		int height = input.nextInt();
		
		System.out.print("Enter the radius of the cylinder: ");
		int radius = input.nextInt();

		double area_cylinder = (2 * 3.14 * radius * height) + (2 * 3.14 * radius * radius);
		System.out.println("Area of the Cylinder: " + area_cylinder);
	}

}
