package day1;

public class Day1 {

	public static void main(String[] args) {

		System.out.println("hello");

	}

}
