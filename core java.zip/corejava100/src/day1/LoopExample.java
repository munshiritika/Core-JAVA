package day1;
//12-21-2023, Thursday
import java.util.Scanner;

public class LoopExample {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Number: ");
		int num = input.nextInt();

		int sum = 0;
		for (int i = 1; i <= num; i++) {
			sum += i;
		}
		System.out.println("The sum of the number: " + sum);

	}
}

