package day1;
//12-22-2023, Friday
public class ShapesAndAreasMain {

	public static void main(String[] args) {
		//Calling the methods we created in ShapeAndAreas class
		ShapeAndAreas.traingle();
		ShapeAndAreas.parallelogram();
		ShapeAndAreas.rhombus();
		ShapeAndAreas.square();
		ShapeAndAreas.rectangle();
	}
}
