/**
 * 
 */
/**
 * 
 */
module corejava100 {
}