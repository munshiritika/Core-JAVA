package week3_encapsulation1;
//01-05-2024, Friday
public class ClassA {
	//Create a class with 4 methods, one with public , one with private , one protected , one with default. 
	//Show there calling scope in the same class, in other class , in other package.
	private int w = 100;
	int x = 200;
	protected int y = 300;
	public int z = 400;
	
	private void method1() {
		System.out.println("This is a private method!!");
	}
	
	void method2() {
		System.out.println("This is a default method!!");
	}
	
	protected void method3() {
		System.out.println("This is a protected method!!");
	}
	
	public void method4() {
		System.out.println("This is a public method!!");
	}

	public static void main(String[] args) {
		ClassA a = new ClassA();
		System.out.println("Class A");
		
		System.out.println("Private W = " + a.w);
		System.out.println("Default X = " + a.x);
		System.out.println("Protected Y = " + a.y);
		System.out.println("Public Z = " + a.z);
		
		a.method1();
		a.method2();
		a.method3();
		a.method4();
	}

}
