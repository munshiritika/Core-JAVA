package week3_encapsulation1;
//01-05-2024, Friday
public class ClassB {

	public static void main(String[] args) {
		ClassA a = new ClassA();
		System.out.println("Class B");
		
		//System.out.println("Private W = " + a.w); //Cannot access private variables.
		System.out.println("Default X = " + a.x);
		System.out.println("Protected Y = " + a.y);
		System.out.println("Public Z = " + a.z);
		
		//a.method1(); //Cannot access private methods
		a.method2();
		a.method3();
		a.method4();

	}

}
