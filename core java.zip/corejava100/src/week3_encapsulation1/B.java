package week3_encapsulation1;
//01-05-2024, Friday
public class B {
	public static void main(String[] args) {
		A a = new A();
		System.out.println("Class B");
		//System.out.println("Private W = " + a.w); //Cannot access private variables.
		System.out.println("Default X = " + a.x);
		System.out.println("Protected Y = " + a.y);
		System.out.println("Public Z = " + a.z);
	}	
}
