package week2;
//12-29-2023, Friday
import java.util.Scanner;
public class VolumesShapes {
	
	int radius = 9;
	int height = 28;
	
	public static void cube() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n for cube: ");
		int n = input.nextInt();
		
		int volume_of_cube = n * n * n;
		System.out.println("Volume of the cube: " + volume_of_cube);
	}
	
	public static void cylinder() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter radius for cylinder: ");
		int r = input.nextInt();
		System.out.print("Enter height for cylinder: ");
		int h = input.nextInt();
		
		double volume_of_cylinder = 3.14 * r * r * h;
		System.out.println("Volume of the cylinder: " + volume_of_cylinder);
	}
	
	public void prism(double base, double height) {		
		double volume_of_prism = base * height;
		System.out.println("Volume of the prism: " + volume_of_prism);
	}
	
	public void pyramid(double base, double height) {		
		double volume_of_pyramid = (base * height)/3;
		System.out.println("Volume of the pyramid: " + volume_of_pyramid);
	}

}
