package week2;
//12-27-2023, Wednesday
public class BikeMain {

	public static void main(String[] args) {
		//calling functions from Bike class
		Bike.characteristics();
		Bike.characteristics("BMW");
		Bike.characteristics("BMW", "Sports");
		Bike.characteristics(10);
		Bike.characteristics("BMW", 2010);
	}
}
