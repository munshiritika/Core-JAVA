package week2;
//12-27-2023, Wednesday
public class Bike {
	
	public static void characteristics() {
		System.out.println("This is a Bike class");
	}
	
	public static void characteristics(String name) {
		System.out.println("This name of the Bike is " + name);
	}
	
	public static void characteristics(String name, String type) {
		System.out.println("The name of the bike is " + name + " with type " + type);
	}
	
	public static void characteristics(int num) {
		System.out.println("The number of bikes are " + num);
	}
	
	public static void characteristics(String name, int year) {
		System.out.println("This Bike named " + name + " is of the year " + year);
	}
	
}
