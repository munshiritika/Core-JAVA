package week2;
//12-29-2023, Friday
import java.util.Scanner;
public class ReverseString {

	public static void reverse_string() {
		Scanner input = new Scanner(System.in); 
	    System.out.print("Enter the string: ");
	    String str = input.nextLine(); 
		
		String rev_str = "";
		int j = 0;
		for(int i = str.length() - 1; i >= 0; i--) {
			rev_str = rev_str + str.charAt(i);
		}
		System.out.println("Reversed String: " + rev_str);
	}
	
	public static void main(String[] args) {
		reverse_string();
	}
}
