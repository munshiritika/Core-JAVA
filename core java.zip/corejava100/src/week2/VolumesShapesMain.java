package week2;
//12-29-2023, Friday
public class VolumesShapesMain {

	public static void main(String[] args) {
		//Calling methods created in VolumesShapes class
		System.out.println("Static methods:");
		VolumesShapes.cube();
		VolumesShapes.cylinder();
		
		VolumesShapes vol = new VolumesShapes();
		System.out.println();
		System.out.println("Non-Static methods:");
		System.out.println("Attributes are: ");
		System.out.println("Radius: " + vol.radius);
		System.out.println("Height: " + vol.height);
		System.out.println("Behaviors are: ");
		vol.prism(10.5, 25.2);
		vol.pyramid(15.0, 23.1);
		
	}

}
