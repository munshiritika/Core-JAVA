package week2;
//12-28-2023, Thursday
public class Cow {
	//Attributes
	String color = "white";
	int number = 10;
	String location = "Africa";
	String adaptability = "Good";
	String weight = "1200 pounds";
	
	//Behaviors
	public void speaks(String ss) {
		System.out.println("Cow says: " + ss + "!!");
	}
	
	public void food() {
		System.out.println("Cow is eating grass!!");
	}

	public void sound() {
		System.out.println("Cow says Moo! Moo!");
	}
	
	public void weightAndHeight(int weight, int height) {
		System.out.println("Cow weights " + weight + " pounds and is " + height + " inches!!");
	}
	
}
