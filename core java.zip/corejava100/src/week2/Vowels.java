package week2;
//12-29-2023, Friday
import java.util.Scanner;
public class Vowels {
	
	public static void vowels() {
		Scanner input = new Scanner(System.in); 
	    System.out.print("Enter the string: ");
	    String str = input.nextLine(); 
	    boolean flag = false;
	    
	    
	    for(int i = 0; i < str.length(); i++) {
	    	if((str.charAt(i) == 'a') || (str.charAt(i) == 'A') || (str.charAt(i) == 'e') || (str.charAt(i) == 'E')
	    		|| (str.charAt(i) == 'i') || (str.charAt(i) == 'I') || (str.charAt(i) == 'o') || (str.charAt(i) == 'O')
	    		|| (str.charAt(i) == 'u') || (str.charAt(i) == 'U')) {
	    		flag = true;
	    		break;
	    	}
	    	else {
	    		flag = false;
	    	}
	    }
	    
	    if(flag == true) {
	    	System.out.println("The string " + str + " does contain vowels.");
	    }
	    else {
	    	System.out.println("The string " + str + " does not contain vowels.");
	    }
	    
	}
	
	public static void main(String[] args) {
		vowels();
	}

}
