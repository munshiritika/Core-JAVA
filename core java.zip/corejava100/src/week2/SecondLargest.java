package week2;
//12-29-2023, Friday
import java.util.Arrays;
import java.util.Scanner;
public class SecondLargest {
	
	public static void secondmax() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		int[] array = new int[n];		
		for(int i = 0; i < n; i++) {
			System.out.print("Enter number " + (i+1) + ": ");
			int num = input.nextInt();
			array[i] = num;			
		}
		System.out.println("Numbers in an array: " + Arrays.toString(array));
		
		int[] arr = array;
		for(int i = 0; i < array.length; i++) {
			for(int j = i+1; j < array.length; j++) {
				int temp = 0;
				if(array[i] > array[j]) {
					temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		System.out.println("Sorted array is " + Arrays.toString(array));
		System.out.println("The second largest number in the array is " + array[array.length-2]);
		
	}

	public static void main(String[] args) {
		secondmax();
	}
}
