package week2;
//12-26-2023, Tuesday
import java.util.Arrays;
import java.util.Scanner;

public class ReverseArray {
	//Write  java code to reverse the element of the array.
	
	public static void reverse_array() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		int[] array = new int[n];		
		for(int i = 0; i < n; i++) {
			System.out.print("Enter number " + (i+1) + ": ");
			int num = input.nextInt();
			array[i] = num;			
		}
		System.out.println("Original array: " + Arrays.toString(array));
		
		int[] new_array = new int[n];
		int j = 0;
		for(int i = array.length - 1; i >= 0; i--) {
			new_array[j++] = array[i];
		}
		System.out.println("Reversed array: " + Arrays.toString(new_array));
	}
	
	public static void main(String[] args) {
		reverse_array();
	}

}
