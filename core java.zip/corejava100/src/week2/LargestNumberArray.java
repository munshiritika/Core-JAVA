package week2;
//12-26-2023, Tuesday
import java.util.Arrays;
import java.util.Scanner;

public class LargestNumberArray {
	//Create a method of finding largest number from an array and call it outside the package.

	public static void largestNumber() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		int[] array = new int[n];		
		for(int i = 0; i < n; i++) {
			System.out.print("Enter number " + (i+1) + ": ");
			int num = input.nextInt();
			array[i] = num;			
		}
		System.out.println("Numbers in an array: " + Arrays.toString(array));
		
		int max_num = array[0];
		for(int i = 0; i < array.length; i++) {
			if(array[i] > max_num) {
				max_num = array[i];
			}
		}
		System.out.println("The Largest Number in the array: " + max_num);
	}
}
