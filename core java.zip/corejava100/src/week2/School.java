package week2;
//12-28-2023, Thursday
public class School {
	
	//Attributes
	String name = "Modern Indian School";
	String location = "Kathmandu";
	int year = 1990;
	String principal = "R Peter";
	int student = 5000;
	
	//Behaviors
	public void name(String name) {
		System.out.println("The name of the school is " + name + ".");
	}

	public void moto(String moto) {
		System.out.println("The moto of the school is " + moto + ".");
	}
	
	public void total(int teachers, int students) {
		System.out.println("The total number of students and teachers in the school is " + (teachers + students)  + ".");
	}
	
	public void location(String location) {
		System.out.println("The school is located at " + location  + ".");
	}
	
	public void average(double avg) {
		System.out.println("The average marks of the students in the school comes out to be " + avg  + ".");
	}
}
