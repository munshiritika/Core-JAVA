package week2;
//12-28-2023, Thursday
public class SchoolMain {

	public static void main(String[] args) {
		
		School school = new School();
		
		//Attributes
		System.out.println("The Attributes are: ");
		System.out.println("Name of the school: " + school.name);
		System.out.println("Location of the school: " + school.location);
		System.out.println("Year of the school: " + school.year);
		System.out.println("Principal of the school: " + school.principal);
		System.out.println("Number of students in the school: " + school.student);
		System.out.println();
		
		//Behaviors
		System.out.println("The Behaviors are: ");
		school.name("D.P.S High School");
		school.moto("Practice makes a man perfect");
		school.total(1950, 1697);
		school.location("New Delhi");
		school.average(87.98);
		
	}

}
