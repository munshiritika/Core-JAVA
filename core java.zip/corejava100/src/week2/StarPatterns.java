package week2;
//12-28-2023, Thursday
import java.util.Scanner;
public class StarPatterns {
	
	//Pattern 1
	public static void pattern1(int n) {
		System.out.println("Pattern 1:");
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) { 
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	
	//Pattern 2
	public static void pattern2(int n) {
		System.out.println("Pattern 2:");
		for (int i = 1; i <= n; i++) {
			for (int k=2*(n-i); k>=0; k--)         
			{        
				System.out.print(" ");   
			} 
			for (int j = 1; j <= i; j++) { 
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	
	//Pattern 3
	public static void pattern3(int n) {
		System.out.println("Pattern 3:");
		for (int i = 1; i <= n; i++) {
			for (int k=n-i; k>1; k--)   
			{   
			System.out.print(" ");   
			}   
			for (int j = 1; j <= i; j++) { 
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	
	
	public static void main(String[] args) {	
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		pattern1(n);
		System.out.println();
		pattern2(n);	
		System.out.println();
		pattern3(n);
	}

}
