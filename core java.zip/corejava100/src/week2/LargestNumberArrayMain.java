package week2;
//12-26-2023, Tuesday
public class LargestNumberArrayMain {

	public static void main(String[] args) {
		//Calling the method we created in LargestNumberArray class		
		LargestNumberArray.largestNumber();
	}

}
