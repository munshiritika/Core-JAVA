package week2;
//12-27-2023, Wednesday
import java.util.Arrays;

public class Library {
	
	public static void name() {
		System.out.println("This is a Library class");
	}
	
	public static void books(String[] book_names, int[] year) {
		String new_array[] = new String[book_names.length];
		
		for(int i=0; i < book_names.length; i++) {
			new_array[i] = book_names[i] + " - " + year[i];
		}
		System.out.println("The new books with year is " + Arrays.toString(new_array));
	}
	
	public static void loan(int[] loaned_book) {
		int sum = 0, max = loaned_book[0], min = loaned_book[0];
		
		for(int i=0; i < loaned_book.length; i++) {
			sum = sum + i;
			if(loaned_book[i] > max) {
				max = loaned_book[i];
			}
			if(loaned_book[i] < min) {
				min = loaned_book[i];
			}
		}
		System.out.println("The total number of books loaned: " + sum);
		System.out.println("The maximum number of books loaned: " + max);
		System.out.println("The minimum number of books loaned: " + min);
	}

}
