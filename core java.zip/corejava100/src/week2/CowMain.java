package week2;
//12-28-2023, Thursday
public class CowMain {

	public static void main(String[] args) {
		//Calling behaviors and attributes from Cow class
		
		Cow cow = new Cow();
		
		System.out.println("The Attribues are: ");
		System.out.println("Color of cows: " + cow.color);
		System.out.println("Number of cows: " + cow.number);
		System.out.println("Location of cows: " + cow.location);
		System.out.println("Adaptability of cows: " + cow.adaptability);
		System.out.println("weight of cows: " + cow.weight);
		System.out.println();
		
		System.out.println("The Behaviors are: ");
		cow.speaks("Hello");
		cow.food();
		cow.sound();
		cow.weightAndHeight(1600, 50);	
	}
}
