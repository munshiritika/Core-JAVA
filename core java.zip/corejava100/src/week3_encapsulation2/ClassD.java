package week3_encapsulation2;
import week3_encapsulation1.ClassA;
//01-05-2024, Friday
public class ClassD extends ClassA {

	public static void main(String[] args) {
		ClassA a = new ClassA();
		System.out.println("Class D");
		//System.out.println("Private W = " + a.w);   //Cannot access private variables
		//System.out.println("Default X = " + a.x);   //C is outside package of A
		//a.method1(); //Cannot access private
		//a.method2(); //ClassC is outside package of ClassA

		ClassD d = new ClassD();
		System.out.println("Protected Y = " + d.y);
		System.out.println("Public Z = " + a.z);
		d.method3();
		d.method4();

	}

}
