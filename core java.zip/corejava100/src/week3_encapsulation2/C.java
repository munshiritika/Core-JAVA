package week3_encapsulation2;
import week3_encapsulation1.A;
//01-05-2024, Friday
public class C {
	public static void main(String[] args) {
		A a = new A();
		System.out.println("Class C");
		//System.out.println("Private W = " + a.w);   //Cannot access private variables
		//System.out.println("Default X = " + a.x);   //C is outside package of A
		//System.out.println("Protected Y = " + a.y); //C does not extend A
		System.out.println("Public Z = " + a.z);		
	}
}
