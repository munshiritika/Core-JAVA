package week3_encapsulation2;
import week3_encapsulation1.A;
//01-05-2024, Friday
public class D extends A {
	public static void main(String[] args) {
		A a = new A();
		System.out.println("Class D");
		//System.out.println("Private W = " + a.w);   //Cannot access private variables
		//System.out.println("Default X = " + a.x);   //C is outside package of A
		
		D d = new D();
		System.out.println("Protected Y = " + d.y);
		System.out.println("Public Z = " + a.z);
	}
}
