package week3_encapsulation2;
import week3_encapsulation1.ClassA;
//01-05-2024, Friday
public class ClassC {

	public static void main(String[] args) {
		ClassA a = new ClassA();
		System.out.println("Class C");
		
		//System.out.println("Private W = " + a.w);   //Cannot access private variables
		//System.out.println("Default X = " + a.x);   //C is outside package of A
		//System.out.println("Protected Y = " + a.y); //C does not extend A
		System.out.println("Public Z = " + a.z);	
		
		//a.method1(); //Cannot access private
		//a.method2(); //ClassC is outside package of ClassA
		//a.method3(); //ClassC does not extend ClassA
		a.method4();

	}

}
