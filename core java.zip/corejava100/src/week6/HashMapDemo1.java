package week6;
//01-23-2024, Tuesday
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo1 {
//Map is unordered according to the keys.
//Everything is according to keys. Keys could be in any order.

	public static void main(String[] args) {
		Map<String, String> hashmap = new HashMap<>();
		
		hashmap.put("ssn008", "soojan");
		hashmap.put("ssn005", "mohan");
		hashmap.put("ssn009", "sabita");
		hashmap.put("ssn001", "soojan");
		hashmap.put("ssn001", "prabhat");
		System.out.println("HashMap: " + hashmap + "\n");
		
		Set<Entry<String, String>> entrySet =  hashmap.entrySet(); //Set of all the rows or set of all the entries, each key-value is an entry, datatype is an entry
		for(Entry<String, String> entry : entrySet) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}
		
	}
}
