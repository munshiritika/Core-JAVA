package week6;
//01-23-2024, Tuesday
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class TreeMapDemo {
//Initially/By default these would in sorted order based on keys.
//To sort based on values we have to write Comparator.
//To sort in descending order for keys as well we have to use Comparator.
//TreeMapDescendingComparator for descending order for keys
	
	public static void main(String[] args) {
		Map<String, String> treemap = new TreeMap<>();
		
		treemap.put("ssn008", "soojan");
		treemap.put("ssn005", "mohan");
		treemap.put("ssn009", "sabita");
		treemap.put("ssn001", "soojan");
		treemap.put("ssn001", "prabhat");
		System.out.println("TreeMap: " + treemap + "\n");
		
		Set<Entry<String, String>> entrySet =  treemap.entrySet(); //Set of all the rows or set of all the entries, each key-value is an entry, datatype is an entry
		for(Entry<String, String> entry : entrySet) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}
		System.out.println();
		
		//Using Comparator to get keys in descending order
		Map<String, String> treemap1 = new TreeMap<>(new TreeMapDescendingComparator());
		
		treemap1.put("ssn008", "soojan");
		treemap1.put("ssn005", "mohan");
		treemap1.put("ssn009", "sabita");
		treemap1.put("ssn001", "soojan");
		treemap1.put("ssn001", "prabhat");
		System.out.println("TreeMap: " + treemap1 + "\n");
		
		Set<Entry<String, String>> entrySet1 =  treemap1.entrySet(); //Set of all the rows or set of all the entries, each key-value is an entry, datatype is an entry
		for(Entry<String, String> entry : entrySet1) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}
		System.out.println();
		
	}
}
