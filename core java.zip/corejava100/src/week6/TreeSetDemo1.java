package week6;
//01-22-2024, Monday
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo1 {
//TreeSet adds elements in the set sorted order.
//TreeSet works based on Comparable and Comparator.
//This sorting implemented using Comparable.
//Want to override default sorting we have to override Comparable.
//TreeSetSortDescending for Comparator.
//We cannot use Collections.sort() for set. It can only be used for list.
	
	public static void main(String[] args) {
		//It will use default sorting which is Comparable. Comparable has been written by one who has written this inbuilt class.
		Set<Integer> treeset1 = new TreeSet<>();
		treeset1.add(4);
		treeset1.add(10);
		treeset1.add(1);
		treeset1.add(100);
		treeset1.add(1);  
		System.out.println("TreeSet of Integer type: " + treeset1);
		
		//It will use custom sorting which Comparator.
		Set<Integer> treeset2 = new TreeSet<>(new TreeSetSortDescending());
		treeset2.add(4);
		treeset2.add(10);
		treeset2.add(1);
		treeset2.add(100);
		treeset2.add(1);  
		System.out.println("TreeSet of Integer type: " + treeset2);
		
		
	}
}
