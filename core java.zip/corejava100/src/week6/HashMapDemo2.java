package week6;
//01-23-2024, Tuesday
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo2 {
//Return type of put method: it is going to return the old value
	
	public static void main(String[] args) {
		Map<String, String> hashmap = new HashMap<>();
		
		hashmap.put("ssn008", "soojan");
		String oldValue = hashmap.put("ssn005", "mohan");
		hashmap.put("ssn009", "sabita");
		hashmap.put("ssn001", "soojan");
		String oldValue1 = hashmap.put("ssn001", "prabhat"); 
		System.out.println("HashMap: " + hashmap + "\n");
		
		System.out.println("OldValue of ssn005: " + oldValue);
		System.out.println("OldValue of ssn001: " + oldValue1 + "\n");
		
		Set<String> keys = hashmap.keySet(); //Find set of all keys, return set of keys
		System.out.println("Keys: " + keys);
		
		Collection<String> values = hashmap.values(); //return collection of values
		System.out.println("Values: " + values + "\n");
		
		boolean flag = hashmap.containsKey("ssn007");
		System.out.println("Containskey ssn007: " + flag);
		boolean flag1 = hashmap.containsKey("ssn001");
		System.out.println("Containskey ssn001: " + flag1);
		
		boolean flag2 = hashmap.containsValue("prabhat");
		System.out.println("ContainsValue prabhat: " + flag2);
		boolean flag3 = hashmap.containsValue("trump");
		System.out.println("ContainsValue trump: " + flag3 + "\n");
	
		
		System.out.println("For loop/Iteration: ");
		Set<Entry<String, String>> entrySet =  hashmap.entrySet(); //Set of all the rows or set of all the entries, each key-value is an entry, datatype is an entry
		for(Entry<String, String> entry : entrySet) {
			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		}
		
	}
}
