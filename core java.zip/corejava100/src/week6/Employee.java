package week6;
//01-22-2024, Monday

import java.util.Objects;

public class Employee implements Comparable<Employee> {
//Comparable is an inbuilt interface that will enable sorting. This is default sorting.
//Comparator interface will provide custom sorting.

	private String name;
	private int age;
	private int salary;
	
	//Default Constructor
	public Employee() {
		super();
	}

	//Parameterized Constructor
	public Employee(String name, int age, int salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getSalary() {
		return salary;
	}
	
	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", salary=" + salary + "]";
	}

	@Override
	public int compareTo(Employee o) {
		//Let's say we want to sort based on age
		return (this.age - o.getAge());   //Ascending Order Sorting
		//return (o.getAge() - this.age); //Descending Order Sorting
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, name, salary);
	}

	//To override equals() method
	//Now it will compare content not address
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return age == other.age && Objects.equals(name, other.name) && salary == other.salary;
	}

	
	
	
}
