package week6;
//01-22-2024, Monday

public class HashCodeDemo1 {

	public static void main(String[] args) {
		//Two different objects cannot have same hashCode -- Exceptional situation
		
		Integer i = new Integer(10);
		System.out.println("HashCode of 10: " + i.hashCode());
		
		String s = new String("Soojan");
		System.out.println("HashCode of Soojan: " + s.hashCode());

		String s1 = new String("Ritika");
		System.out.println("HashCode of Ritika: " + s1.hashCode());
		
		String s2 = new String("Ri");
		System.out.println("HashCode of Ri: " + s2.hashCode());
		
		String s3 = new String("prabh");
		System.out.println("HashCode of prabh: " + s3.hashCode());
		
		Integer i2 = new Integer(106926885);
		System.out.println("HashCode of 106926885: " + i2.hashCode());
		
		String s4 = new String("prabh");
		System.out.println("HashCode of prabh: " + s4.hashCode());
	
		System.out.println("Content Equals: " + s3.equals(s4)); //content is same so true, both are different object but their hashCode is same
		//If two objects are same by equals method then their hashCode should also be same. This is because string class is already overriding hashCode and equals.
		
	}
}
