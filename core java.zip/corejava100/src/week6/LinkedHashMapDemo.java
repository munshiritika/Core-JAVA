package week6;
//01-23-2024, Tuesday
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class LinkedHashMapDemo {
//LinkedHashMap is used to maintain order of a map.

	public static void main(String[] args) {
		Map<String, String> linkedhashmap = new LinkedHashMap<>();
		
		linkedhashmap.put("ssn008", "soojan");
		linkedhashmap.put("ssn005", "mohan");
		linkedhashmap.put("ssn009", "sabita");
		linkedhashmap.put("ssn001", "soojan");
		linkedhashmap.put("ssn001", "prabhat");
		System.out.println("LinkedHashMap: " + linkedhashmap);

	}
}
