package week6;
//01-22-2024, Monday

import java.util.Objects;

public class HashCodeDemo2 {

	public static void main(String[] args) {
		Employee employee1 = new Employee("Ritika", 22, 90000);
		Employee employee2 = new Employee("Rahul", 21, 70000);
		
		System.out.println("HashCode of employee1: " + employee1.hashCode());
		System.out.println("HashCode of employee2: " + employee2.hashCode());
		System.out.println("Equals: " + employee1.equals(employee2));
	
		Dog dog1 = new Dog(); //tommy, 12
		Dog dog2 = new Dog(); //tommy, 12
		
		System.out.println("HashCode of dog1: " + dog1.hashCode());
		System.out.println("HashCode of dog2: " + dog2.hashCode());
		System.out.println("Equals: " + dog1.equals(dog2)); //false if we have not overridden equals method so it would compare address not content by default
		//equals is true hashCode also has to be same -- but here hashCode is not same because hashCode is not overridden
	}
}


class Dog {
	String name = "tommy";
	int age = 12;
	
	@Override
	public int hashCode() {
		return Objects.hash(age, name);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dog other = (Dog) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	
}