package week6;
//01-23-2024, Tuesday
import java.util.Comparator;

public class TreeMapDescendingComparator implements Comparator<String>{
//TreeMapDemo
	
	@Override
	public int compare(String o1, String o2) {
		return (o2.compareTo(o1));
	}

}
