package week6;
//01-23-2024, Tuesday
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo1 {
//This is ordered set. LinkedHashSet is used for maintaining order.
	
	public static void main(String[] args) {
		Set<Integer> linkedhashset1 = new LinkedHashSet<Integer>();

		linkedhashset1.add(4);
		linkedhashset1.add(10);
		linkedhashset1.add(1);
		linkedhashset1.add(100);
		linkedhashset1.add(100);
		System.out.println("LinkedHashSet: " + linkedhashset1 + "\n");
		
		System.out.println("For-Each Loop:");
		for(int element : linkedhashset1) {
			System.out.println("Element: " + element);
		}
		
	}
}
