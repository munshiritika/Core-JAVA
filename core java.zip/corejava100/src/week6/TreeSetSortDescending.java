package week6;
//01-22-2024, Monday
import java.util.Comparator;

public class TreeSetSortDescending implements Comparator<Integer> {
//TreeSetDemo1 for main method.
	
	@Override
	public int compare(Integer o1, Integer o2) {
		return (o2-o1);
	}

}
