package week5;
//01-19-2024, Friday
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo1 {
	
	public static void main(String[] args) {
		List<Integer> linkedlist1 = new LinkedList<>();
		linkedlist1.add(1);
		linkedlist1.add(2);
		linkedlist1.add(3);
		linkedlist1.add(4);
		linkedlist1.add(5);
		System.out.println("LinkedList of Integer type: " + linkedlist1);

	}

}
