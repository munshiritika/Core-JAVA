package week5;
//01-18-2024, Thursday
import java.util.Comparator;

public class EmployeeComparator implements Comparator<Employee> {
//Employee Class
//Comparator interface will provide custom sorting.
	
	@Override
	public int compare(Employee e1, Employee e2) {
		return (e1.getName().compareTo(e2.getName()));  //Ascending Order Sorting
	}

}
