package week5;
//01-15-2024, Monday
import java.util.Scanner;

public class ExceptionDemo6 {
	
	static String takeInput() throws Exception {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the name you want: ");
		String enteredName = scanner.next();
	
		if(enteredName.equals("Ritika")) {
			Exception exception = new Exception("Ritika is not allowed.");
			throw exception;
		}
		return enteredName;		
	}
	
	public static void main(String[] args) {
		String enteredName = null;
		try {
			enteredName = takeInput();
		}
		catch(Exception execp) {
			System.out.println(execp.getMessage());
			return;
		}
		System.out.println("Welcome " + enteredName);
	}
	
}
