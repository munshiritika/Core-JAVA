package week5;
//01-19-2024, Friday
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DuplicateUniqueHashSetFromArray {
//Print all the duplicate elements of this array using Set(HashSet)
//Print all the unique elements of of this array using Set(HashSet)
	
	public static void uniques(int[] array) {
		Set<Integer> unique = new HashSet<>();
		for(int i = 0; i < array.length; i++) {
			unique.add(array[i]);
		}
		System.out.println("Unique Elements: " + unique);
	}
	
	public static void duplicates(int[] array) {
		Set<Integer> duplicate = new HashSet<>();
		int value = 0;
		boolean flag = false; 
  
        for (int i = 0; i < (array.length-1); i++) { 
            for (int j = i + 1; j < array.length; j++) { 
                if (array[i] == array[j]) { 
                    if (value == array[i]) {      //check if element match to duplicate one
                        break; 
                    } 
                    else {                        //check if element does not match to duplicate one
                    	value = array[i];
                    	duplicate.add(array[i]); 
                        flag = true; 
                    } 
                } 
            } 
        } 
  
        if (flag == true) {  //if duplicate if present then print the HashSet
            System.out.print("Duplicate Elements: " + duplicate); 
        } 
        else { 
            System.out.print("No Duplicate value."); 
        } 
	}
	
	//Calling uniques and duplicates method
	public static void main(String[] args) {
		int[] array = {9,6,5,6,3,9};
		System.out.println("Original Array: " + Arrays.toString(array));
		uniques(array);
		duplicates(array);
	}
}
