package week5;
//01-17-2024, Wednesday
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo3 {

	public static void main(String[] args) {
		List<Integer> arraylist = new ArrayList<>(); 
		arraylist.add(1);
		arraylist.add(2);
		arraylist.add(3);
		arraylist.add(4);
		arraylist.add(5);
		System.out.println("ArrayList: " + arraylist);
	
		System.out.println("\nFor loop:");
		//Iteration using for loop
		for(int i = 0; i < arraylist.size(); i++) {
			System.out.println("Element: " + arraylist.get(i));
		}
		
		System.out.println("\nFor-each loop:");
		//Iteration using for-each loop; also known as advanced for loop
		for(int element : arraylist) {
			System.out.println("Element: " + element);
		}
		
		System.out.println("\nIterator:");		
		//Iteration using iterator; iterator will be provided by collection framework
		Iterator<Integer> iterator = arraylist.iterator();
		while(iterator.hasNext()) {
			System.out.println("Element: " + iterator.next());
		}
		
		System.out.println("\nDouble each element of ArrayList:");
		//I want to multiply every element by 2 and print
		for(int element : arraylist) {
			System.out.println("Element: " + (element*2));
		}
		
	}
}
