package week5;
//01-16-2024, Tuesday
import java.util.Scanner;
public class IsPalindrome {
	
	public static void isPalindrome() {
		Scanner input = new Scanner(System.in); 
	    System.out.print("Enter the string: ");
	    String str = input.nextLine(); 
		
		String rev_str = "";
		int j = 0;
		for(int i = str.length() - 1; i >= 0; i--) {
			rev_str = rev_str + str.charAt(i);
		}
		System.out.println("Reversed String: " + rev_str);
		
		if(str.equals(rev_str)) {
			System.out.println("The string is a palindrome!");
		}
		else {
			System.out.println("The string is not a palindrome!");
		}
	}

	public static void main(String[] args) {
		isPalindrome();
	}
	
}
