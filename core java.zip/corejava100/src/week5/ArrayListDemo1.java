package week5;
//01-17-2024, Wednesday
import java.util.ArrayList;

public class ArrayListDemo1 {
//ArrayList is collection of elements just like array.
//In ArrayList, these would be stored in memory as contagious memory location manner. If some scattered memory location is available then ArrayList is not helpful, then LinkedList is used because in LinkedList one holds the memory of the other one it is a chain.
//In ArrayList, to delete some in between is not easy because then we have to copy and paste the next element for all the rest of others. But in LinkedList, we only move the pointer to the next one.
//In ArrayList, searching is easy because of index we can calculate the address and find. But searching is hard in LinkedList because we have to follow the path from one to next to find an element.
//Arrays are static but any collection such as ArrayList is dynamic.
//In Array, size of array is fixed so at runtime we cannot increase or decrease the memory but size of ArrayList is not fixed which means at runtime we can store as many elements we want to store and size can also be decreased.
//ArrayList class is implementing List interface.
	
	public static void main(String[] args) {
		ArrayList arraylist1 = new ArrayList(); //It will create a blank ArrayList with no elements contained.
		arraylist1.add(4);
		arraylist1.add(10);
		arraylist1.add("Ritika");
		System.out.println("ArrayList1 of any type: " + arraylist1);
		
		//Mostly ArrayList do not contained mixed type of data.
		//<Integer> is called generic.
		
		ArrayList<Integer> arraylist2 = new ArrayList<>();
		arraylist2.add(1);
		arraylist2.add(2);
		arraylist2.add(3);
		arraylist2.add(4);
		arraylist2.add(5);
		//arraylist2.add("Ritika");  //This will show error as this list can only contain integers.
		System.out.println("ArrayList2 of Integer type: " + arraylist2);
	
		ArrayList<String> arraylist3 = new ArrayList<>();
		arraylist3.add("Ritika");
		arraylist3.add("Harshit");
		arraylist3.add("Vedant");
		arraylist3.add("Prity");
		//arraylist3.add(1);  //This will show error as this list can only contain strings.
		System.out.println("ArrayList3 of String type: " + arraylist3);
	}

}
