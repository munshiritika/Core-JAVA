package week5;
//01-19-2024, Friday
import java.util.HashSet;
import java.util.Set;

public class EmployeeHashSetDemo2 {
//Employee Class
//Employee is a custom class. Class created by programmer.
	
	public static void main(String[] args) {
		Set<Employee> setOfEmployee = new HashSet<>();
		
		//Create some employees
		Employee employee1 = new Employee("Soojan", 19, 800);
		Employee employee2 = new Employee("Dipesh", 21, 1200);
		Employee employee3 = new Employee("Ruksha", 17, 700);
		Employee employee4 = new Employee("Ruksha", 17, 700); //by content assumed as duplicate
		
		//Add these employees to set
		setOfEmployee.add(employee1);
		setOfEmployee.add(employee2);
		setOfEmployee.add(employee3);
		setOfEmployee.add(employee4);  //Added if we do not have hashCode and equals overridden in Employee Class
		System.out.println("Adding employees to set: ");
		System.out.println(setOfEmployee + "\n");

	}
}
