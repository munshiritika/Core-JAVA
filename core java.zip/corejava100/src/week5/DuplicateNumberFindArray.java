package week5;
//01-16-2024, Tuesday
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class DuplicateNumberFindArray {
//How do you find the duplicate number on a given integer array?Assume array contains only one duplicate number.
	
	public static void duplicates(int[] array) {
		int value = 0;
		boolean flag = false; 
  
        for (int i = 0; i < (array.length-1); i++) { 
            for (int j = i + 1; j < array.length; j++) { 
                if (array[i] == array[j]) { 
                    if (value == array[i]) {      //check if element match to duplicate one
                        break; 
                    } 
                    else {                        //check if element does not match to duplicate one
                        value = array[i]; 
                        flag = true; 
                    } 
                } 
            } 
        } 
  
        if (flag == true) {  //if duplicate if present then print the value
            System.out.print("Duplicate value: " + value); 
        } 
        else { 
            System.out.print("No Duplicate value."); 
        } 
	}
	
	//calling duplicates method
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = input.nextInt();
		
		int[] array = new int[n];
		
		for(int i = 0; i < n; i++) {
			System.out.print("Enter number " + (i+1) + ": ");
			int num = input.nextInt();
			array[i] = num;			
		}
		System.out.println("Array: " + Arrays.toString(array));
		
		duplicates(array);
    } 		
	
}

