package week5;
//01-19-2024, Friday
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetDemo1 {
//Set is an unordered collection. Order does not matter.
//Set is dynamic. It does not allow duplicates. It is based on hashCode mechanism.
//Unordered: add(2)->6->7; there is no guarantee that it would be like {2,6,7}, it may be like {6,2,7} or {7,6,2}. It can go in any order it is adding.
//HashSet is very important.
	
	public static void main(String[] args) {
		Set<Integer> hashset1 = new HashSet<>();
		System.out.println("Initial Size of HashSet: " + hashset1.size());
		hashset1.add(4);
		hashset1.add(10);
		hashset1.add(1);
		hashset1.add(100);
		hashset1.add(1);  //It will not get added as this is will duplicate. Will return false as this will be added.
		System.out.println("HashSet of Integer type: " + hashset1);
		System.out.println("Size of HashSet after adding: " + hashset1.size());
	
		System.out.println("\nFor-each loop:");
		for(int element : hashset1) {
			System.out.println("Element: " + element);
		}
		
		System.out.println("\nIterator:");		
		Iterator<Integer> iterator = hashset1.iterator();
		while(iterator.hasNext()) {
			System.out.println("Element: " + iterator.next());
		}

	}
}
