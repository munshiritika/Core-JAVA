package week5;
//01-19-2024, Friday

import java.util.Comparator;

public class DescendingSortComparable implements Comparator<Integer>{
//DescendingSortArrayList Class
//Comparator Class used to sort integers in descending order
	
	@Override
	public int compare(Integer value1, Integer value2) {
		//descending order sorting
		return (value2 - value1);
	}
	
}
