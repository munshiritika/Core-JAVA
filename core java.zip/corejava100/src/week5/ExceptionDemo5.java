package week5;
//01-15-2024, Monday
import java.util.Scanner;
public class ExceptionDemo5 {
	//Creating our own exception
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the name you want: ");
		String enteredName = scanner.next();
		
		try {
			if(enteredName.equals("Ritika")) {
				Exception exception = new Exception("Ritika is not allowed.");
				throw exception;
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return;
		}
		System.out.println("Welcome " + enteredName);
	}
	
}
