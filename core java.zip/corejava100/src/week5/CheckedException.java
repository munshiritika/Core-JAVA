package week5;
//01-15-2024, Monday
public class CheckedException {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.jdbc.driver");
		}
		catch(ClassNotFoundException excep) {
			
		}
	}
	
}
