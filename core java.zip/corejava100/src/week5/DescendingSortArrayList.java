package week5;
//01-19-2024, Friday
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DescendingSortArrayList {

	public static void main(String[] args) {
		List<Integer> listOfIntegers = new ArrayList<>();
		listOfIntegers.add(8);
		listOfIntegers.add(18);
		listOfIntegers.add(9);
		listOfIntegers.add(10);
		listOfIntegers.add(7);
		System.out.println("Original ArrayList: " + listOfIntegers);
		
		//Uses default sorting, here in ascending order
		Collections.sort(listOfIntegers);
		System.out.println("Ascending Sorted ArrayList: " + listOfIntegers);
		
		//I want to sort in descending order
		//We need Comparator Class for sorting in Descending Order
		//This is implemented in DescendingSortComparable Class
		Collections.sort(listOfIntegers, new DescendingSortComparable());
		System.out.println("Descending Sorted ArrayList: " + listOfIntegers);
	}
}
