package week5;
//01-18-2024, Thursday
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeArrayListDemo {
//Employee Class
//Employee is a custom class. Class created by programmer.
	
	public static void main(String[] args) {
		List<Employee> listOfEmployee = new ArrayList<>();
		
		//Create some employees
		Employee employee1 = new Employee("Soojan", 19, 800);
		Employee employee2 = new Employee("Dipesh", 21, 1200);
		Employee employee3 = new Employee("Ruksha", 17, 700);
		
		//Add these employees to list
		listOfEmployee.add(employee1);
		listOfEmployee.add(employee2);
		listOfEmployee.add(employee3);
		System.out.println("Adding employees to list: ");
		System.out.println(listOfEmployee + "\n");
		
		//Java does not know about Employee class this is your class. They don't know how to sort these Employee. Java will ask how to sort. Is it based on Name, Age or Salary.
		//We have to implement Comparable interface in Employee class for us to do sorting here.
		//This will sort based on age as we implemented compareTo based on age.
		//Default Sorting
		Collections.sort(listOfEmployee);  
		System.out.println("Sorting employees based on age: ");
		System.out.println(listOfEmployee + "\n");
		
		//Custom Sorting
		//Sort based on name.
		EmployeeComparator empCompByName = new EmployeeComparator();
		Collections.sort(listOfEmployee, empCompByName); 
		System.out.println("Sorting employees based on name: ");
		System.out.println(listOfEmployee + "\n");
		
	}
}
