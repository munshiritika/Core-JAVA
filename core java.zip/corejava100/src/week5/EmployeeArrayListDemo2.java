package week5;
//01-18-2024, Thursday
import java.util.ArrayList;
import java.util.List;

public class EmployeeArrayListDemo2 {
//Employee Class
//Employee is a custom class. Class created by programmer.
	
	public static void main(String[] args) {
		List<Employee> listOfEmployee = new ArrayList<>();
		
		//Create some employees
		Employee employee1 = new Employee("Soojan", 19, 800);
		Employee employee2 = new Employee("Dipesh", 21, 1200);
		Employee employee3 = new Employee("Ruksha", 17, 700);
		
		//Add these employees to list
		listOfEmployee.add(employee1);
		listOfEmployee.add(employee2);
		listOfEmployee.add(employee3);
		System.out.println("Adding employees to list: ");
		System.out.println(listOfEmployee + "\n");
		
		//Search, contains method internally calls equals method
		//By default equals method compares address not content
		//In real life, we are more concerned with content not address
		//false if equals is not overridden in Employee class
		//true if equals is overridden in Employee class
		Employee employee4 = new Employee("Ruksha", 17, 700);
		System.out.println("Search employee4 in list: ");
		System.out.println(listOfEmployee.contains(employee4)); 

	}

}
