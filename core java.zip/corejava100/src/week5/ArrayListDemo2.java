package week5;
//01-17-2024, Wednesday
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo2 {
//ArrayList class is implementing List interface.
	
	public static void main(String[] args) {
		//ArrayList<Integer> arraylist1 = new ArrayList<>();
		List<Integer> arraylist = new ArrayList<>();  //This is better
		System.out.println("ArrayList size initially: " + arraylist.size());
		arraylist.add(4);
		arraylist.add(3);
		arraylist.add(2);
		arraylist.add(5);
		arraylist.add(1);
		System.out.println("ArrayList: " + arraylist);
	
		//Important Operations over ArrayList
		System.out.println("ArrayList size after adding: " + arraylist.size());
		System.out.println("Get first element: " + arraylist.get(0));
		System.out.println("Get last element: " + arraylist.get(4));
		System.out.println("Remove by index: " + arraylist.remove(0));
		System.out.println("ArrayList after removing first element: " + arraylist);
		Collections.sort(arraylist);
		System.out.println("Sorted List: " + arraylist);
		
	}
}
