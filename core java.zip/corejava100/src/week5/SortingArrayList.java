package week5;
//01-18-2024, Thursday
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingArrayList {
//Create ArrayList of 5 Integers and sort them in descending order.
	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(20);
		list.add(50);
		list.add(3);
		list.add(100);
		list.add(70);
		list.add(2);
		System.out.println("Original List: " + list);
		
		//Sort the ArrayList in Ascending Order
		Collections.sort(list);
		System.out.println("Ascending Order Sorting: " + list);
		
		//Reverse traversal and make a Descending Order ArrayList
		List<Integer> des_sorted_list = new ArrayList<>();
		for(int i = (list.size()-1); i > 0; i--) {
			des_sorted_list.add(list.get(i));
		}
		System.out.println("Descending Order Sorting: " + des_sorted_list);
			
	}
}
