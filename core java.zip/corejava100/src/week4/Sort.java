package week4;
//01-08-2024, Monday
public interface Sort {
	//abstract class will be used for code re-useability which is in the case of inheritance
	//interface provide communication between two application to expose functionality/methods to outside world.
	
	int[] sort(int[] array);
}
