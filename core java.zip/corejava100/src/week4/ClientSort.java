package week4;
//01-08-2024, Monday
public class ClientSort {
	//ClientAdd does not know how SortImplementation is implemented.
	public static void main(String[] args) {
		//Use the Interface Add
		Sort sort = new SortImplementation(); //creating reference of interface not object
		
		int[] array = new int[]{ 1,2,7,8,9,10,3,43 };
		
		System.out.println("Ascending order");
		int[] sorted_array = sort.sort(array);
		for(int i:sorted_array) {
			System.out.println(i);
		}
		
		System.out.println();
		
		System.out.println("Descending order");
		sort = new SortImplementationTwo();
		int[] sorted_array2 = sort.sort(array);
		for(int i:sorted_array2) {
			System.out.println(i);
		}
	}

}
