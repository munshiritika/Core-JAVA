package week4;
//01-08-2024, Monday
public class CarMain {

	public static void main(String[] args) {
		//calling the methods implemented
		
		Car car = new CarImplementation();
		String name = car.carName("Honda");
		String model = car.carModel("Accord");
		String year = car.carYear(2023); 
		String location = car.carLocation("United States");
		String state = car.carStateRegistration("Maryland");

		System.out.println(name);
		System.out.println(model);
		System.out.println(year);
		System.out.println(location);
		System.out.println(state);	
	}
}
