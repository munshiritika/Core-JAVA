package week4;
//01-11-2024, Thursday
public class StringDemo4 {
	public static void main(String[] args) {
		//Strings are immutable
		//once object is created you cannot modify
		
		String str1 = "soojan";
		
		str1 = str1 + "nepal";  //another object would be created but str1 will point here now and the previous point would be gone
		str1 = str1 + "usa";    //another object would be created but str1 will point here now and the previous point would be gone

		//If we need mutable string object then we need to use StringBuilder and StingBuffer classes.
		//if multiple user want to access same object which is synchronization which is why it is less efficient --> StringBuffer
		//StringBuilder is a class and is more recommended over StringBuffer
		//StringBuffer is synchronized, i.e. thread safe. It is less efficient than StringBuilder.
		//Equals method is not overridden in StringBuffer, so it is just reference equality
		
		//same object is going to be modified so this is mutable object. It can be modified again and again.
		StringBuilder strbuild = new StringBuilder("12345");
		strbuild.append("67");  //1234567
		System.out.println("Append: " + strbuild);
		strbuild.delete(0, 2);  //34567   //delete index 0 and index 1
		System.out.println("Delete: " + strbuild);
		strbuild.reverse();     //76543
		System.out.println("Reverse: " + strbuild);
		
		//Chain of methods can be implemented
		StringBuilder strbuild1 = new StringBuilder("Test");
		strbuild1.append("Java").delete(0, 4).insert(0,  "Begin");
		System.out.println("Append,Delete,Insert: " + strbuild1);
		
		//memory location is different for both so false
		//to compare content we cannot override StringBuilder class as it is inbuilt class. We can modify instance of StringBuilder class.
		//toString method will convert StringBuilder to String object
		StringBuilder strbuild2 = new StringBuilder("Mohan");
		StringBuilder strbuild3 = new StringBuilder("Mohan");
		System.out.println("Equals method: " + strbuild2.equals(strbuild3));
		System.out.println("Equals ontent: " + strbuild2.toString().equals(strbuild3.toString()));
	}
}
