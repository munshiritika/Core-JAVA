package week4;
//01-08-2024, Monday
import java.util.Arrays;
public class SortImplementation implements Sort {

	@Override
	public int[] sort(int[] array) {
		//Sorting in Ascending order
		Arrays.sort(array);
		return array;
	}

}
