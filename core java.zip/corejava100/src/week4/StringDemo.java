package week4;
//01-09-2024, Tuesday
public class StringDemo {
	//String is an inbuilt class in JAVA.
	public static void main(String[] args) {
		
		//Way-1 to create String using String Literals
		//This object will be created in intern pool memory
		//intern pool does not allow duplicate elements
		//multiple variables with Micheal value will point to one place with Micheal value
		String name = "Micheal"; //Micheal is an object. name is a reference variable type string pointing to Micheal
		String name1 = "Dan";
		
		
		//Way-2 to create String using new keyword
		//This will be created in heap area memory
		//multiple variables with Annie will point to different Annie being created
		String str = new String("Annie");	
		String str1 = new String("Vicky");
		
		//Operations, if any operand is String then result will always be a String
		System.out.println("Ram" + "Mohan"); //String = RamMohan
		System.out.println(5+"Mohan");       //String = 5Mohan
		System.out.println(5+5+"Mohan");     //String = 10Mohan
		System.out.println(5+5+"Mohan"+5);   //String = 10Mohan5
		System.out.println(5+5+"Mohan"+5+5); //String = 10Mohan55
	}
}
