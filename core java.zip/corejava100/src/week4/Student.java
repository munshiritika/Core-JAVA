package week4;
//01-08-2024, Monday
public abstract class Student {
	//Abstraction is hiding implementation details.
	//abstract method -> we need to have abstract class
	
	public abstract void walk(); //abstract method no definition
	
	public void run() {
		System.out.println("This is the run method of Student Class!!");
	}
	
	public void jump() {
		System.out.println("This is the jump method of Student Class!!");
	}
	
}
