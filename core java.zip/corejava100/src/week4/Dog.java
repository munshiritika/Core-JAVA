package week4;
//01-10-2024, Wednesday
import java.util.Objects;
public class Dog {
	//StringDemo3.java is the one where we have main function to call on
	String name;
	int age;
	String color;
	
	public Dog(String name, int age, String color) {
		super();
		this.name = name;
		this.age = age;
		this.color = color;
	}
//
//	@Override
//	public int hashCode() {
//		return Objects.hash(age, color, name);
//	}

	//if we want to compare the content so we override equals in Dog class
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dog other = (Dog) obj;
		return age == other.age && Objects.equals(color, other.color) && Objects.equals(name, other.name);
	}
}
