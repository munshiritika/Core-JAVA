package week4;
//01-12-2024, Friday
public class ExceptionExample3 {
	public static void main(String[] args) {
		int result = 0;
		
		try {
			int x = 100;
			int y = 20;
			int z = 0;
			
			result = x/z;
			System.out.println("This line will be executed if no exception before it!!");
		}
		catch(Exception e) {
			e.printStackTrace(); //print exception details
		}
		System.out.println("Result: " + result);
		System.out.println("There was no exception or exception was handled!!");
	}
}
