package week4;
//01-08-2024, Monday
public interface Car {
	//Create a interface Car with 5 abstract method , Create a implementation class and implement it.
	
	String carName(String name);
	String carModel(String model);
	String carYear(int year);
	String carLocation(String location);
	String carStateRegistration(String registration);

}
