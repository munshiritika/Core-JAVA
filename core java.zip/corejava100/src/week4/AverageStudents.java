package week4;
//01-08-2024, Monday
public class AverageStudents extends Student {

	@Override
	public void walk() {
		System.out.println("I am an average student while walking in AverageStudents Class!!");		
	}
	
	@Override
	public void jump() {
		System.out.println("I am jumping on my own from AverageStudents Class!!");
	}
	
	public static void main(String[] args) {
		//calling methods created
		System.out.println("AverageStudents Class");
		System.out.println("-----------------------");
		Student student = new AverageStudents();
		student.walk();
		student.run(); //this is not overridden it is inherited but we can override and re-implement in this class
		student.jump(); //this is overridden and re-implemented
		
		System.out.println();
		
		System.out.println("BrilliantStudents Class");
		System.out.println("-------------------------");
		student = new BrilliantStudents();
		student.walk();
	}
}
