package week4;
//01-13-2024, Friday
import java.util.Arrays;

public class CopyArray {

	public static void main(String[] args) {
		
		int[] arr = {1, 2, 3, 4, 5};
		int[] array_copy = new int[5];
		for(int i = 0; i < arr.length; i++) {
			array_copy[i] = arr[i];
		}
		
		
		System.out.println("Original Array:  " + Arrays.toString(arr));
		System.out.println("Copied Array:  " + Arrays.toString(array_copy));
	}

}
