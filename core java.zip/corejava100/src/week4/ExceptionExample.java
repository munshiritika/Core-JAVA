package week4;
//01-12-2024, Friday
public class ExceptionExample {
	//No Exception Handling
	public static void main(String[] args) {
		int x = 100;
		int y = 20;
		int z = 0;
		
		int result = x/y;
		System.out.println("Result: " + result);
		
		int result1 = x/z;
		System.out.println("Result1: " + result1);
	}
}
