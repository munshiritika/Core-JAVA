package week4;
//01-12-2024, Friday
public class ExceptionExample4 {
	public static void main(String[] args) {
		int x = 100;
		int y = 20;
		int z = 0;
		int result = 0;
		
		try {		
			result = x/z;
			System.out.println("This line will be executed if no exception before it!!");
		}
		catch(Exception e) {
			e.printStackTrace(); //print exception details
		}
		finally{
			System.out.println("Finally will be executed always. No matter if exception has occured or not.");
		}
		System.out.println("Result: " + result);
		System.out.println("There was no exception or exception was handled!!");
		
		System.out.println();
		System.out.println();
		
		try {		
			result = x/y;
			System.out.println("This line will be executed if no exception before it!!");
		}
		catch(Exception e) {
			e.printStackTrace(); //print exception details
		}
		finally{
			System.out.println("Finally will be executed always. No matter if exception has occured or not.");
		}
		System.out.println("Result: " + result);
		System.out.println("There was no exception or exception was handled!!");
	
	}
}
