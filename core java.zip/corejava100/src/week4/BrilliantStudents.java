package week4;
//01-08-2024, Monday
public class BrilliantStudents extends Student {

	@Override
	public void walk() {
		System.out.println("I am a brilliant student while walking in BrilliantStudents Class!!");		
	}

}
