package week4;
//01-08-2024, Monday
public class CarImplementation implements Car {

	@Override
	public String carName(String name) {
		String str = "The name of the car is " + name + ".";
		return str;
	}

	@Override
	public String carModel(String model) {
		String str = "The model of the car is " + model + ".";
		return str;
	}

	@Override
	public String carYear(int year) {
		String yr = "The year the car is modeled is " + year + ".";
		return yr;
	}

	@Override
	public String carLocation(String location) {
		String str = "The location of the car is " + location + ".";
		return str;
	}

	@Override
	public String carStateRegistration(String registration) {
		String str = "The state of registration of the car is " + registration + ".";
		return str;
	}

}
