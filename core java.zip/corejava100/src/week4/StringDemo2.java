package week4;
//01-09-2024, Tuesday
public class StringDemo2 {

	public static void main(String[] args) {
		String name = "Micheal"; 
		String name1 = "Dan";
		String name2 = "Joseph";
		
		//Find length of a String
		System.out.println(name.length());  //7
		System.out.println(name1.length()); //3
		System.out.println(name2.length()); //6
		
		//SubString()..
		System.out.println(name.substring(1));    //icheal
		System.out.println(name.substring(0));    //Micheal
		System.out.println(name.substring(6));    //l
		System.out.println(name.substring(0, 5)); //Miche : first is inclusive, last is exculsive
		System.out.println(name.substring(0, 0)); //no output
		System.out.println(name.substring(6, 6)); //no output
		
		//CharAt(index)
		System.out.println(name.charAt(0));
		System.out.println(name.charAt(5));
		System.out.println(name.charAt(6));
		System.out.println(name1.charAt(name1.length()-1));
	}
}
