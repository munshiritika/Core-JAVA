package week4;
//01-12-2024, Friday
public class ExceptionExample2 {
	public static void main(String[] args) {
		int x = 100;
		int y = 20;
		int z = 0;
		int result = 0;
		
		try {
			result = x/z;
		}
		catch(Exception e) {
			e.printStackTrace(); //print exception details
		}
		System.out.println("Result: " + result);
		System.out.println("There was no exception or exception was handled!!");
	}
}
