package week4;
//01-10-2024, Wednesday
public class StringDemo3 {
	public static void main(String[] args) {
		
		String str1 = "soojan";
		String str2 = "ram";
		String str3 = "prabhat";
		String str4 = "abcdef";
		String str5 = "soojan";
		String str6 = new String("soojan");
		
		//contains
		System.out.println(str4.contains("c")); //true
		System.out.println(str4.contains("p")); //false
		
		//compareTo --> compares lexicographically meaning in dictionary order
		System.out.println(str1.compareTo(str5)); //0
		System.out.println(str1.compareTo(str2)); //1
		System.out.println(str4.compareTo(str3)); //-15
		
		//equals() --> compares the contents for string. It is overridden by String 
		//by default in string class compares contents
		System.out.println(str1.equals(str5)); //true
		System.out.println(str1.equals(str4)); //false
		System.out.println(str1.equals(str6)); //true
		
		//== --> compare references for string
		System.out.println(str1 == str5); //true
		System.out.println(str1 == str6); //false
		
		System.out.println("----------");
		
		//Dog Class
		Dog dog1 = new Dog("tommy", 5, "black");
		Dog dog2 = new Dog("jacky", 15, "white");
		Dog dog3 = new Dog("tommy", 5, "black");
		
		//compares references as this does not come from String class this is inherited one
		//by default class will compare references
		System.out.println(dog1.equals(dog2));
		System.out.println(dog1.equals(dog3)); //false if equals() not overridden in Dog class
	}
}
