package week3;
//01-05-2024, Friday
public class School {
	//Create a class with 3 constructor and 2 methods and call them.
	
	String name;
	String location;
	
	public School() {
		System.out.println("This is first constructor.");
	}
	
	public School(String name) {
		this.name = name;
		System.out.println("This is second constructor with school name as " + name + ".");
	}
	
	public School(String name, String location) {
		this.name = name;
		this.location = location;
		System.out.println("This is third constructor with school name as " + name + " located in " + location + ".");
	}
	
	public void departments(String[] depts) {
		for(int i = 0; i < depts.length; i++) {
			System.out.println("This is a " + depts[i] + " department.");
		}
	}
	
	public void total(int teachers, int students) {
		int total = teachers + students;
		System.out.println("The total number of students and teachers we have in school = " + total + ".");
	}
	
}
