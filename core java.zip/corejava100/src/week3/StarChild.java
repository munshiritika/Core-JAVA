package week3;
//01-04-2024, Thursday
public class StarChild extends StarParent {

}
