package week3;
//01-02-2024, Tuesday
public class SchoolLibraryMain {

	public static void main(String[] args) {
		//Calling the methods from SchoolParent and LibraryChild
		
		System.out.println("Parent Class: SchoolParent Class");
		System.out.println("---------------------------------");
		SchoolParent school = new SchoolParent();
		school.name("Modern Indian School");
		school.location("Kathmandu");
		school.total(25, 90);
		school.average(89.90);	
		
		System.out.println();
		System.out.println("************************************************************************");
		System.out.println();
		
		System.out.println("Child Class: LibraryChild Class");
		System.out.println("--------------------------------");
		LibraryChild library = new LibraryChild();
		library.bookName("One Hundred Years of Solitude");
		library.bookAndYear("One Hundred Years of Solitude", 1967);
		library.loan(50);
		library.teachers(8);
		library.name("DPS School");
		library.location("Delhi");
		library.total(50, 100);
		library.average(95.68);
	}
}
