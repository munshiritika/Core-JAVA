package week3;
//01-02-2024, Tuesday
public class BikeMain {

	public static void main(String[] args) {
		//Calling constructors and methods from Bike class
		Bike bike;
		
		bike = new Bike();
		bike.characteristics();
		bike.names("Harley");
		bike.nameWithType("Harley", "BMW");
		bike.numOfBikes(20);
		bike.yearBike("Harley", 2005);
		
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.println();
		
		bike = new Bike("Sport Bikes");
		bike.characteristics();
		bike.names("Yamaha");
		bike.nameWithType("Yamaha", "Sports");
		bike.numOfBikes(30);
		bike.yearBike("Yamaha", 2010);
		
		System.out.println();
		System.out.println("-------------------------------------");
		System.out.println();
		
		bike = new Bike("Sport Bikes", 100);
		bike.characteristics();
		bike.names("Honda");
		bike.nameWithType("Honda", "Scooter");
		bike.numOfBikes(60);
		bike.yearBike("Honda", 2021);
	}
}
