package week3;
//01-03-2024, Wednesday
public class Aerodog extends Dog {
	
	String jumpHeight="10M";
	
	void fly() {
		System.out.println("i am special dog and i am flying now  in the child class");
	}
	
	void swim() {
		System.out.println("i am special dog and i am swimming now  in the child class");
	}

}
