package week3;
//01-04-2024, Thursday
public class StudentMain {

	public static void main(String[] args) {
		//calling methods from student class
		
		Student student = new Student();	
		System.out.println("Id is " + student.getId());
		System.out.println("Name is " + student.getName());
		System.out.println("Password is " + student.getPassword());
		System.out.println(student);
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println();
		
		student.setName("Ritika Munshi");
		student.setId(120);
		student.setPassword("Ritika123!");
		System.out.println("Id is " + student.getId());
		System.out.println("Name is " + student.getName());
		System.out.println("Password is " + student.getPassword());
		System.out.println(student);
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println();
	
		student.setId(-100);
		System.out.println("Id is " + student.getId());
		System.out.println(student);
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println();
		
		student.setId(0);
		System.out.println("Id is " + student.getId());
		System.out.println(student);

	}

}
