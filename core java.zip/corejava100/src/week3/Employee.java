package week3;
//01-04-2024, Thursday
public class Employee {
	
	private int EmployeeID;
	private String EmployeeName;
	private int EmployeeSalary;
	private int Employeeage;
	
	public int getEmployeeID() {
		return EmployeeID;
	}
	
	public void setEmployeeID(int employeeID) {
		if(employeeID < 0) {
			System.out.println("EmployeeID is unaunthorized!!");
		}
		else {
			EmployeeID = employeeID;
		}
	}
	
	public String getEmployeeName() {
		return EmployeeName;
	}
	
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	
	public int getEmployeeSalary() {
		return EmployeeSalary;
	}
	
	public void setEmployeeSalary(int employeeSalary) {
		EmployeeSalary = employeeSalary;
	}
	
	public int getEmployeeage() {
		return Employeeage;
	}
	
	public void setEmployeeage(int employeeage) {
		Employeeage = employeeage;
	}
	
	@Override
	public String toString() {
		return "Employee [EmployeeID=" + EmployeeID + ", EmployeeName=" + EmployeeName + ", EmployeeSalary="
				+ EmployeeSalary + ", Employeeage=" + Employeeage + "]";
	}
	
}
