package week3;
//01-02-2024, Tuesday
public class ParentChildMain {

	public static void main(String[] args) {
		//Calling methods and constructors from Parent and Child class
		
		//Parent class
		Parent parent;
		
		parent = new Parent();
		parent.averages();
		parent.factorial(10);
		parent.positiveOrNegative(-1);
		parent.reverse_string("This is a string");
		
		System.out.println();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		parent = new Parent("Tiger");
		parent.averages();
		parent.factorial(10);
		parent.positiveOrNegative(-1);
		parent.reverse_string("This is a string");
		
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		parent = new Parent("Tiger", "Non-Vegetarian");
		parent.averages();
		parent.factorial(10);
		parent.positiveOrNegative(-1);
		parent.reverse_string("This is a string");
		
		System.out.println();
		System.out.println("--------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		parent = new Parent("Tiger", "Orange", 4);
		parent.averages();
		parent.factorial(10);
		parent.positiveOrNegative(-1);
		parent.reverse_string("This is a string");
		
		System.out.println();
		System.out.println("************************************************************************************************************");
		System.out.println();
		
		//Child class
		Child child;
		
		child = new Child();
		child.reverse_array();
		child.isPalindrome("abcba");
		child.cube(5);
		child.vowels("Hello");
		child.averages();
		child.factorial(20);
		child.positiveOrNegative(9);
		child.reverse_string("Let's reverse");
		
		System.out.println();
		System.out.println("------------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		child = new Child("brown");
		child.reverse_array();
		child.isPalindrome("abcba");
		child.cube(5);
		child.vowels("Hello");
		child.averages();
		child.factorial(20);
		child.positiveOrNegative(9);
		child.reverse_string("Let's reverse");
		
		System.out.println();
		System.out.println("---------------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		child = new Child("brown", "bulldog");
		child.reverse_array();
		child.isPalindrome("abcba");
		child.cube(5);
		child.vowels("Hello");
		child.averages();
		child.factorial(20);
		child.positiveOrNegative(9);
		child.reverse_string("Let's reverse");
		
		System.out.println();
		System.out.println("-----------------------------------------------------------------------------------------------------------------");
		System.out.println();
		
		child = new Child(25);
		child.reverse_array();
		child.isPalindrome("abcba");
		child.cube(5);
		child.vowels("Hello");
		child.averages();
		child.factorial(20);
		child.positiveOrNegative(9);
		child.reverse_string("Let's reverse");
		
	}

}
