package week3;
//01-02-2024, Tuesday
public class Bike {
	//constructors
	public Bike() {
		System.out.println("This is the first non-parametrised constructor for Bike class.");
	}
	
	public Bike(String type) {
		System.out.println("This is the second constructor with type " + type + ".");
	}
	
	public Bike(String type, int num) {
		System.out.println("This is the third constructor of type " + type + " with total " + num + " of bikes." );
	}
	
	//methods
	public void characteristics() {
		System.out.println("This is a Bike class");
	}
	
	public void names(String name) {
		System.out.println("This name of the Bike is " + name);
	}
	
	public void nameWithType(String name, String type) {
		System.out.println("The name of the bike is " + name + " with type " + type);
	}
	
	public void numOfBikes(int num) {
		System.out.println("The number of bikes are " + num);
	}
	
	public void yearBike(String name, int year) {
		System.out.println("This Bike named " + name + " is of the year " + year);
	}
	

}
