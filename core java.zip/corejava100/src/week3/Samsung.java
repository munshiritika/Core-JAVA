package week3;
//01-03-2024, Wednesday
public class Samsung extends Mobile {
	
	@Override
	public void ringtone() {
		System.out.println("This is a child class with its own Samsung ringtone.");
	}

}
