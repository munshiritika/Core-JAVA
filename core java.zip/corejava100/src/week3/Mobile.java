package week3;
//01-03-2024, Wednesday
public class Mobile {
	
	public void color() {
		System.out.println("This is a parent class with a Mobile.");
	}

	public void ringtone() {
		System.out.println("This is a parent class with its own ringtone.");
	}
}
