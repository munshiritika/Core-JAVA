package week3;
//01-03-2024, Wednesday
public class DogAerodogMain {

	public static void main(String[] args) {
		Dog dog=new Dog();
		dog.jump();
		dog.run();
		
		System.out.println("---------------------------------------------------------------------------");
		
		Aerodog aerodog=new Aerodog();		
		aerodog.jump();
		aerodog.run();
		
		aerodog.fly();
		aerodog.swim();
		
		System.out.println("---------------------------------------------------------------------------");
		
		dog=new Aerodog();
		dog.jump();
		dog.run();
		((Aerodog)dog).fly();//downcasting
		((Aerodog)dog).swim();

	}

}
