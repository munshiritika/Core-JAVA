package week3;
//01-03-2024, Wednesday
public class MobileSamsungMain {

	public static void main(String[] args) {
		//Calling methods from Mobile and Samsung
		
		Mobile mobile = new Mobile();
		mobile.color();
		mobile.ringtone();
		
		System.out.println();
		System.out.println("----------------------------------------------------------");
		System.out.println();
		
		mobile = new Samsung();
		mobile.ringtone();
	}

}
