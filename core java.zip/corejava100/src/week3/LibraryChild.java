package week3;
//01-02-2024, Tuesday
public class LibraryChild extends SchoolParent{
	
	public void bookName(String name) {
		System.out.println("The name of the book is " + name + ".");
	}

	public void bookAndYear(String name, int year) {
		System.out.println("The book " + name + " was launched in the year " + year + ".");
	}
	
	public void loan(int loans) {
		System.out.println("The total number of books loans:" + loans  + ".");
	}
	
	public void teachers(int num) {
		System.out.println("The total number teachers working in the library:" + num  + ".");
	}
	
}
