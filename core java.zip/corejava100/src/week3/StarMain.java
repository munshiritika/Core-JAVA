package week3;
//01-04-2024, Thursday
public class StarMain {

	public static void main(String[] args) {
		//Calling methods from StarParent and StarChild class as a part of inheritance
		
		StarParent star = new StarParent();
		star.pattern1(5);
		star.pattern2(5);
		star.pattern3(5);
		star.pattern4(5);
		
		System.out.println();
		System.out.println("------------------------------------------");
		System.out.println();
		
		StarChild child = new StarChild();
		child.pattern1(3);
		child.pattern2(3);
		child.pattern3(3);
		child.pattern4(3);
	}
}
