package week3;
//01-04-2024, Thursday
public class Student {
	//Encapsulation
	
	//Attributes
	private int id;
	private String name;
	private String password;
	
	//Id getter
	public int getId() {
		return id;
	}
	
	//Id setter
	public void setId(int id) {
		if(id < 0) {
			System.out.println("Id can not be a negative value!!");
		}
		else if(id == 0) {	
			System.out.println("Id is zero!!");
		}
		else {
			this.id = id;
		}
	}
	
	//Name getter
	public String getName() {
		return name;
	}
	
	//Name setter
	public void setName(String name) {
		this.name = name;
	}
	
	//Password Getter
	public String getPassword() {
		return password;
	}
	
	//Password Setter
	public void setPassword(String password) {
		this.password = password;
	}
	
	//toString method
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", password=" + password + "]";
	}

}
