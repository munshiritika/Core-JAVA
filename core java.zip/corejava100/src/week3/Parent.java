package week3;
//01-02-2024, Tuesday
import java.util.Arrays;
import java.util.Scanner;
public class Parent {
	//class Animal
	
	//Constructors
	public Parent() {
		System.out.println("This is the first constructor of our parent class which is Animal!");		
	}
	
	public Parent(String name) {
		System.out.println("This is the second constructor with name of the animal is " + name + ".");
	}

	public Parent(String name, String food) {
		System.out.println("This is the third constructor whith name of the animal is " + name + " and is " + food);
	}
	
	public Parent(String name, String color, int legs) {
		System.out.println("This is the fourth constructor with name of the animal is " + name + ". It is of " + color + " color. It has " + legs + " legs.");
	}
	
	//Methods
	public void averages() {
		double average = 0;
		double sum = 0;
		
		int[] array = {1, 2, 3, 4, 5};
		for(int i = 0; i < 5; i++) {
			sum = sum + array[i];
		}
		average = sum/5;
		
		System.out.println("Numbers in an array: " + Arrays.toString(array));
		System.out.println("Sum of " + 5 + " numbers: " + sum);
		System.out.println("Average of " + 5 + " numbers: " + average);
	}
	
	public void factorial(int num) {
		long fact = 1;
		for (int i = 1; i <= num; i++) {
			fact *= i;
		}
		System.out.println("Factorial: " + fact);
	}
	
	public void positiveOrNegative(int num) {
		if (num > 0) {
			System.out.println(num + " is a Positive Number!!");
		}
		else if (num < 0) {
			System.out.println(num + " is a Negative Number!!");
		} else {
			System.out.println("Zero!!");
		}
	}
	
	public void reverse_string(String str) {
		String rev_str = "";
		int j = 0;
		for(int i = str.length() - 1; i >= 0; i--) {
			rev_str = rev_str + str.charAt(i);
		}
		System.out.println("Reversed String: " + rev_str);
	}
	
}
