package week3;
//01-04-2024, Thursday
public class EmployeeMain {
	public static void main(String[] args) {
		//Calling methods created in Employee class with Getters, Setters and toString
		
		Employee employee = new Employee();
		System.out.println("Id is " + employee.getEmployeeID());
		System.out.println("Name is " + employee.getEmployeeName());
		System.out.println("Salary is " + employee.getEmployeeSalary());
		System.out.println("Age is " + employee.getEmployeeage());
		System.out.println(employee);
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println();
		
		employee.setEmployeeName("Micheal Sullivan");
		employee.setEmployeeID(120);
		employee.setEmployeeSalary(120000);
		employee.setEmployeeage(30);
		System.out.println("Id is " + employee.getEmployeeID());
		System.out.println("Name is " + employee.getEmployeeName());
		System.out.println("Salary is " + employee.getEmployeeSalary());
		System.out.println("Age is " + employee.getEmployeeage());
		System.out.println(employee);
		
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println();
	
		employee.setEmployeeID(-100);
		System.out.println("Id is " + employee.getEmployeeID());
		System.out.println(employee);
	}
}
