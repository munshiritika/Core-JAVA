package week3;
//01-05-2024, Friday
public class SchoolMain {

	public static void main(String[] args) {
		//Calling constructors and methods from School class
		
		School school = new School();
		String[] depts = {"Mathematics", "Computer Science", "English", "Social Science"};
		school.departments(depts);
		school.total(58, 138);
		
		System.out.println();
		System.out.println("---------------------------------------------------------------------------------------");
		System.out.println();
		
		School school1 = new School("Kendra Vidyalaya");
		String[] depts1 = {"History", "Computer Engineering", "Literature", "Science"};
		school1.departments(depts1);
		school1.total(46, 126);
		
		System.out.println();
		System.out.println("---------------------------------------------------------------------------------------");
		System.out.println();
		
		School school2 = new School("Modern Indian School", "Chobhar, Kathmandu");
		String[] depts2 = {"Geography", "Chemistry", "Physics", "Biology"};
		school2.departments(depts2);
		school2.total(52, 112);
	}
}
