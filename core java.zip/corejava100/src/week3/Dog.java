package week3;
//01-03-2024, Wednesday
public class Dog {

	String name="jacky";
	String color="black";
	int price=100;
	
	void run(){			
		System.out.println("i am dog ang i am running now in the parent class");
	}
			
    void jump(){			
		System.out.println("i am dog ang i am jumping now in the parent class");
	}
}
