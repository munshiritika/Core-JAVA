package week3;
//01-02-2024, Tuesday
public class SchoolParent {
	
	public void name(String name) {
		System.out.println("The name of the school is " + name + ".");
	}
	
	public void location(String location) {
		System.out.println("The school is located in " + location  + ".");
	}

	public void total(int teachers, int students) {
		System.out.println("The total number of students and teachers in the school is " + (teachers + students)  + ".");
	}
	
	public void average(double avg) {
		System.out.println("The average marks of the students in the school comes out to be " + avg  + ".");
	}

}
