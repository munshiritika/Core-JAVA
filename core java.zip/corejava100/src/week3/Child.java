package week3;
//01-02-2024, Tuesday
import java.util.Arrays;
import java.util.Scanner;
public class Child extends Parent{
	//class Dog
	
	//Constructors
	public Child() {
		System.out.println("This is the first constructor of our child class which is Dog!");
	}
	
	public Child(String color) {
		System.out.println("This is the second constructor with color of the dog is " + color + ".");
	}
	
	public Child(String color, String breed) {
		System.out.println("This is the third constructor with color of the dog is " + color + ". The breed of this dog is " + breed + ".");
	}
	
	public Child(int num) {
		System.out.println("This is the fourth constructor with " + num + "dogs.");
	}
	
	//Methods
	public void reverse_array() {		
		int[] array = {1,2,3,4,5};		
		System.out.println("Original array: " + Arrays.toString(array));
		
		int[] new_array = new int[5];
		int j = 0;
		for(int i = array.length - 1; i >= 0; i--) {
			new_array[j++] = array[i];
		}
		System.out.println("Reversed array: " + Arrays.toString(new_array));
	}
	
	public void isPalindrome(String str) {
		String rev_str = "";
		int j = 0;
		for(int i = str.length() - 1; i >= 0; i--) {
			rev_str = rev_str + str.charAt(i);
		}
		System.out.println("Reversed String: " + rev_str);
		
		if(str.equals(rev_str)) {
			System.out.println("The string is a palindrome!");
		}
		else {
			System.out.println("The string is not a palindrome!");
		}
	}
	
	public void cube(int n) {
		int volume_of_cube = n * n * n;
		System.out.println("Volume of the cube: " + volume_of_cube);
	}
	
	public void vowels(String str) {
	    boolean flag = false;
	    
	    for(int i = 0; i < str.length(); i++) {
	    	if((str.charAt(i) == 'a') || (str.charAt(i) == 'A') || (str.charAt(i) == 'e') || (str.charAt(i) == 'E')
	    		|| (str.charAt(i) == 'i') || (str.charAt(i) == 'I') || (str.charAt(i) == 'o') || (str.charAt(i) == 'O')
	    		|| (str.charAt(i) == 'u') || (str.charAt(i) == 'U')) {
	    		flag = true;
	    		break;
	    	}
	    	else {
	    		flag = false;
	    	}
	    }
	    
	    if(flag == true) {
	    	System.out.println("The string " + str + " does contain vowels.");
	    }
	    else {
	    	System.out.println("The string " + str + " does not contain vowels.");
	    }  
	}

}
